#!/bin/bash
`mkdir /cygdrive/c/Users/brandon/AppData/Local/Google/Chrome/User\ Data/Default/Extensions/llgdbfaibmaehnbknamkpknoillaffll/0.1.15_1`
`find -iname \* -not -name \*.sh -not -name \*~ -not -name .\* | xargs -i cp -r {} /cygdrive/c/Users/brandon/AppData/Local/Google/Chrome/User\ Data/Default/Extensions/llgdbfaibmaehnbknamkpknoillaffll/0.1.15_1`;
